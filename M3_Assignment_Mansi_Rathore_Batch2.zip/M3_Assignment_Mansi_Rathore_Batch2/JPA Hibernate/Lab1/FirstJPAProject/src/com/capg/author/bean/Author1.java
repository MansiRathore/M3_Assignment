package com.capg.author.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table

public class Author1 {

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	
	private int AuthorID;
	
	private String F_name;
	@Override
	public String toString() {
		return "Author1 [AuthorID=" + AuthorID + ", F_name=" + F_name + ", M_name=" + M_name + ", L_name=" + L_name
				+ ", phone_num=" + phone_num + "]";
	}

	private String M_name;
	private String L_name;
	private int phone_num;
	
	public int getAuthorID() {
		return AuthorID;
	}

	public void setAuthorID(int authorID) {
		AuthorID = authorID;
	}

	public String getF_name() {
		return F_name;
	}

	public void setF_name(String f_name) {
		F_name = f_name;
	}

	public String getM_name() {
		return M_name;
	}

	public void setM_name(String m_name) {
		M_name = m_name;
	}

	public String getL_name() {
		return L_name;
	}

	public void setL_name(String l_name) {
		L_name = l_name;
	}

	public int getPhone_num() {
		return phone_num;
	}

	public void setPhone_num(int phone_num) {
		this.phone_num = phone_num;
	}

	public Author1()
	{
		super();
	}
}