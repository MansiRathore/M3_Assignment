package com.capg.author.DAO;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capg.author.bean.Author1;

public class CRUD_Service2 {

	static EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("FirstJPAProject");
	static EntityManager entityManager = emfactory.createEntityManager();
	
	public  static void main(String args[]){
		
		CRUD_Service2 crud_serviceObj2 = new CRUD_Service2();
	
		Author1 authorObj1 = new Author1();
		authorObj1.setAuthorID(55);
		authorObj1.setF_name("Mansi");
		authorObj1.setM_name("Kumari");
		authorObj1.setL_name("Rathore");
		authorObj1.setPhone_num(989898988);
		
		crud_serviceObj2.InsertIntoAuthorDB(authorObj1);
		
		System.out.println("Data Added Successfully");
		System.out.println("MANSI.......");
		System.out.println("Author Id: "+authorObj1.getAuthorID());
		System.out.println("Firs name is: "+authorObj1.getF_name());	
		System.out.println("Middle name is:"+authorObj1.getM_name());
		System.out.println("Last name is: "+authorObj1.getL_name());
		
		System.out.println("Author phone number is: "+authorObj1.getPhone_num());	
}

	 void InsertIntoAuthorDB(Author1 authorObj1) {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
		entityManager.persist(authorObj1);
		entityManager.getTransaction().commit();
	}
}
