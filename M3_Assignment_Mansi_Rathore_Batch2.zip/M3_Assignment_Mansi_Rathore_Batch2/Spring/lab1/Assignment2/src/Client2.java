import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Client2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				ApplicationContext context=new ClassPathXmlApplicationContext("Bean2.xml");
				Employee2 obj=(Employee2) context.getBean("hello");
				Scanner sc=new Scanner(System.in);
				System.out.println("MANSI");
				System.out.println("Enter the Employee id:");
				int id=sc.nextInt();
				if(id==obj.getEmp_id()){			
				System.out.println("printing details of employee");

				System.out.println("Employee id:"+obj.getEmp_id());
				System.out.println("Employee name:"+obj.getEmp_name());
				System.out.println("Employee salary:"+obj.getSal());
				
					}
				else
				{
					System.out.println("Inavlid Employee id:Please entercorrect Emp_Id");
				}

				}
			}