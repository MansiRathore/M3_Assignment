import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("Bean.xml");


		SBU object=(SBU) context.getBean("employee");
		System.out.println("MANSI");
		System.out.println("Printing Sbu details are:");
		System.out.println("Sbu code is:"+object.getSbuCode());
		System.out.println("Sbu name is:"+object.getSbuName());
		System.out.println("Sbu head is"+object.getSbuHead());
		
		Employee1 ob =new Employee1();
		ob.setEmpId(12345);
		ob.setEmpName("Harriet");
		ob.setSal(40000);
		object.setEmpList(ob);
		Employee1 ob1=new Employee1();
		ob1.setEmpId(123456);
		ob1.setEmpName("Charriet");
		ob1.setSal(30000);
		object.setEmpList(ob1);
			
		object.displayInfo();
		
	}

}