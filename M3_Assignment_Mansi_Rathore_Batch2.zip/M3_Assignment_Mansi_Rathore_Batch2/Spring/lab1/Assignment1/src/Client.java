import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = 
				new ClassPathXmlApplicationContext ("hellobean.xml");
		
		Employee obj = (Employee) context.getBean("hello");
		
		System.out.println("printing employee details::");
		System.out.println("MANSI");
		
		System.out.println("Employee id: "+obj.getId());
		System.out.println("Employee Name: "+obj.getName());
		System.out.println("Employee salary:"+obj.getSalary());
		System.out.println("Employee BU:"+obj.getBu());
		System.out.println("Emplyee age:"+obj.getAge());
	}

	
	
}
