package com.sunsoft.BootException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootExceptionApplication.class, args);
		System.out.println("Mansi");

	}

}
