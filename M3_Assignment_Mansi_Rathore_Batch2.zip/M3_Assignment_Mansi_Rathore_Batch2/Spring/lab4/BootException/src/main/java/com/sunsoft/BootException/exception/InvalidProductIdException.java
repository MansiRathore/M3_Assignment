package com.sunsoft.BootException.exception;

public class InvalidProductIdException extends Exception {

	public InvalidProductIdException(String str)
	{
		super(str);
	}
}
