package com.sunsoft.BootException.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.BootException.Entity.Product;
import com.sunsoft.BootException.exception.InvalidProductIdException;
import com.sunsoft.BootException.exception.InvalidProductNameException;

import ch.qos.logback.core.net.SyslogOutputStream;



@RestController
public class EmployeeController {
/*	String strValidProduct=new String();
	@GetMapping(path="/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> index(@RequestParam("ProductId") int ProductId,
			@RequestParam("name") String name)throws InvalidProductIdException,InvalidProductNameException
	{
		if(ProductId<=0)
			throw new InvalidProductIdException("Exception:Invalid id");
		
		else
             System.out.println("Mansi");
			strValidProduct="valid product";
	  System.out.println("name value"+name);
	  
	  if(name.equals(""))
		  throw new InvalidProductNameException("Inavalid product name ");
	  return new ResponseEntity<>(strValidProduct, HttpStatus.OK);
	}
	
	@ExceptionHandler(InvalidProductIdException.class)
	public ResponseEntity<String> handleException (Exception ex)
	{
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}*/
	
	  

	@GetMapping(value = "/product/param", params = "version=1")
	 public Product productver() {
		    Product product =new Product();
		    product.setId(1);
		    
		    
		    product.setName("LG TV");
		    return product;
}
}