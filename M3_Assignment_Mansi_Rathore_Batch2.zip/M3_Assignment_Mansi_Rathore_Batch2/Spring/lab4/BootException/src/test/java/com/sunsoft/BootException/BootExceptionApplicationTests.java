package com.sunsoft.BootException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
